let listaFatos = [


// prencher abaixo:
{
    image: "fotosFatos/projetoAbigail.JPG')",
    link: "pagesFatos/projetoAbigail.php",
    title: "Projeto Abigail", 
    synopsis: "Resumo do meu texto",
},



];//Fim da lista///////////////////////////

