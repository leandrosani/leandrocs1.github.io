let listaCreepy = [
    
// prencher abaixo:
{
    image: "fotosCreepys/espiritoDeUmSuicida.jpg')",
    link: "pagesCreepys/espiritoDeUmSuicida.php",
    title: "Relato sobre o espírito de um suicida", 
},    

// prencher abaixo:
{
    image: "fotosCreepys/isoladaNaSala.JPG')",
    link: "pagesCreepys/isoladaNaSala.php",
    title: "Isolada Na Sala", 
},


];//Fim da lista///////////////////////////


